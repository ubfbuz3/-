# coding=utf-8
# Author: HSJ
# 2023/9/18 16:15
# 检测thinkphp的漏洞
from TpTools import TpTools

if __name__ == '__main__':
    print("*************TP漏洞检测工具*************")
    url = "http://www.thinks332.com/"
    tools = TpTools(url)
    print("拥有的检测版本：")
    tools.output_version()
    num = input("请选择检测的版本:")
    tools.check_version(num)
